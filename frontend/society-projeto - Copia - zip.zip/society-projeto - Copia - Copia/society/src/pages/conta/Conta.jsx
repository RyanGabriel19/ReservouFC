import Footer from "../../components/footer/Footer";
import Header from "../../components/header/Header";

function Conta (){
    return(
        <>
        <Header />
        <Footer />
        </>
    )
}
export default Conta;