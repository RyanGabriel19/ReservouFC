import { Link } from "react-router-dom";
import Footer from "../../components/footer/Footer";
import Header from "../../components/header/Header";

function Agendamento (){
    return(
    <>
        <div>
            <Header/>
            <h1>Agendamento</h1>
            <Footer/>
        </div>
    </>
    )
}

export default Agendamento 